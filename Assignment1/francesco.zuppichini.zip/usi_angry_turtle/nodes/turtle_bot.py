#!/usr/bin/env python
import roslib
roslib.load_manifest('usi_angry_turtle')
import rospy
from geometry_msgs.msg  import Twist
from turtlesim.msg import Pose
from math import pow,atan2,sqrt
from turtlesim.srv import SetPen, TeleportAbsolute, Spawn
from std_srvs.srv import Empty
import turtlesim.msg
import tf
import geometry_msgs.msg
import turtlesim.srv
import math
import threading
from utils import write_usi
from ServiceTurtle import ServiceTurle
import time

PI = 3.1415926535897

K2 = 3
K1 = 1

class State:
    IDLE = 'idle'
    ANGRY = 'angry'
    WRITING = 'writing'
    RETURNING = 'returning'

class TurtleBot():
    def __init__(self, name):
        self.name = name
        #Creating our node,publisher and subscriber
        self.pose_subscriber = rospy.Subscriber('/' + self.name + '/pose', Pose, self.callback)
        self.pos_publisher = rospy.Publisher('/' + self.name  + '/cmd_vel', Twist, queue_size=10)
        self.pose = Pose()
        self.rate = rospy.Rate(10)
        self.service = ServiceTurle(name)
        self.set_pen  = self.service.set_pen
        self.teleport = self.service.teleport
        self.listener = tf.TransformListener()
        self.state = State.IDLE 
        self.last_pose = None

    #Callback function implementing the pose value received
    def callback(self, data):
        self.pose = data
        self.pose.x = round(self.pose.x, 4)
        self.pose.y = round(self.pose.y, 4)

    def get_distance(self, goal_x, goal_y):
        distance = sqrt(pow((goal_x - self.pose.x), 2) + pow((goal_y - self.pose.y), 2))
        return distance

    def spawn(self,x,y,theta):
        rospy.wait_for_service('spawn')
        spawner = rospy.ServiceProxy('spawn', Spawn)  
        # ServiceTurle.get_srv('spawn', Spawn)(x, y, theta, self.name)
        spawner(x,y,theta,self.name)

    def move2goal(self, x, y):
        goal_pose = Pose()
        goal_pose.x = x
        goal_pose.y = y
        distance_tolerance = 0.5 

        vel_msg = Twist()
        while sqrt(pow((goal_pose.x - self.pose.x), 2) + pow((goal_pose.y - self.pose.y), 2)) >= distance_tolerance and self.state != State.RETURNING:
            self.listen()

            if self.state == State.ANGRY: continue
            #Porportional Controller
            #linear velocity in the x-axis:
            vel_msg.linear.x = 1.5 * sqrt(pow((goal_pose.x - self.pose.x), 2) + pow((goal_pose.y - self.pose.y), 2))
            vel_msg.linear.y = 0
            vel_msg.linear.z = 0

            #angular velocity in the z-axis:
            vel_msg.angular.x = 0
            vel_msg.angular.y = 0
            vel_msg.angular.z = 4 * (atan2(goal_pose.y - self.pose.y, goal_pose.x - self.pose.x) - self.pose.theta)

            #Publishing our vel_msg
            self.pos_publisher.publish(vel_msg)
            self.rate.sleep()
        self.listen()
        #Stopping our robot after the movement is over
        vel_msg.linear.x = 0
        vel_msg.angular.z =0
        self.pos_publisher.publish(vel_msg)

    def listen(self):
        rate = rospy.Rate(10.0)

        try:
            (trans,rot) = self.listener.lookupTransform('/' + self.name, '/turtle2', rospy.Time(0))

            distance = sqrt(pow(trans[0], 2) + pow(trans[1],2))

            is_close = distance < K2 or self.state == State.ANGRY

            if is_close:
                if distance < K2 and self.state != State.RETURNING:
                    self.state = State.ANGRY
                    self.last_pose = self.pose if self.last_pose == None else self.last_pose
                    self.set_pen(0,0,0,0,1)
                    angular = 4 * math.atan2(trans[1], trans[0])
                    linear = 0.5 * math.sqrt(trans[0] ** 2 + trans[1] ** 2)
                    cmd = Twist()
                    cmd.linear.x = linear
                    cmd.angular.z = angular
                    self.pos_publisher.publish(cmd)

                if distance < K1 and self.state != State.RETURNING:
                    self.state = State.RETURNING
                    self.draw(clear=True)


            rate.sleep()
                    
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
            pass

    def draw(clear=False):
        pass

class DrawUsiTurtle(TurtleBot):
    def draw(self, clear=False):
        if clear:
            ServiceTurle.get_srv('clear', Empty)()
        self.state = State.WRITING
        self.set_pen(0,0,0,0,1)
        self.teleport(1,7,-PI/2)
        # draw 'U'
        self.set_pen(255,255,255,2,0)
        self.move2goal(1, 3)
        self.move2goal(2, 2)
        self.move2goal(3, 2)
        self.move2goal(4, 3)
        self.teleport(4,3,PI/2)
        self.move2goal(4, 7)
        # draw 'S'
        self.set_pen(0,0,0,0,1)
        self.teleport(5,2,-PI/4)
        self.set_pen(255,255,255,2,0)
        self.move2goal(5.5, 2)
        self.move2goal(6.5, 2)
        self.move2goal(8, 3)
        self.move2goal(6.5, 4.5)
        self.move2goal(5, 5.5)
        self.move2goal(7, 6.5)
        self.move2goal(8, 6.5)
        # draw 'I'
        self.set_pen(0,0,0,0,1)
        self.teleport(9,7,-PI/2)
        self.set_pen(255,255,255,2,0)
        self.move2goal(9, 1)

if __name__ == '__main__':
    rospy.init_node('turtlebot_controller', anonymous=True)

    my_turtle = DrawUsiTurtle(name='turtle1')

    # WHY I can't do something like this?
    # my_turtle2 = TurtleBot(name='turtle2')
    # my_turtle2.spawn(4, 5, 0)    
    # my_turtle2.set_pen(0,0,0,0,1)

    spawner = ServiceTurle.get_srv('spawn',turtlesim.srv.Spawn)
    spawner(4,5,0, 'turtle2')
    
    set_pen = rospy.ServiceProxy('/turtle2/set_pen', SetPen)
    set_pen(0,0,0,0,1)

    my_turtle.state = State.WRITING
    my_turtle.draw()
    # listen to incoming turtles after drawing -> TODO this is an hugly way to to that
    while True:
        my_turtle.listen()
        time.sleep(0.1)
        



    


        
