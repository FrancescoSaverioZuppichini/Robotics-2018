#!/usr/bin/env python
import roslib
roslib.load_manifest('usi_angry_turtle')
import turtlesim.srv as srv
import rospy


class ServiceTurle:
    def __init__(self,name):
        self.name = name
        self.set_pen = ServiceTurle.get_srv('/' + self.name + '/set_pen', srv.SetPen)
        self.teleport = ServiceTurle.get_srv('/' + self.name + '/teleport_absolute', srv.TeleportAbsolute)

    @staticmethod
    def get_srv(service_name, srv_type):
        rospy.wait_for_service(service_name)
        print 'getted service', service_name
        return rospy.ServiceProxy(service_name, srv_type)
